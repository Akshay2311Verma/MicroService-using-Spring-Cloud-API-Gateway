package com.product.main.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.main.model.Product;
import com.product.main.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository repo;
	
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	public void saveProduct(Product product) {
		
		repo.save(product);
		
	}

	public List<Product> fetchByProductId(int id) {
		return repo.findById(id);
	}
	

	/*
	 * public Product updateProductId(Product product, int id) { Product pro =
	 * repo.findById(id); pro.setProduct_Category(product.getProduct_Category());
	 * pro.setProduct_Name(product.getProduct_Name());
	 * pro.setProduct_Price(product.getProduct_Price()); return pro; }
	 */

}

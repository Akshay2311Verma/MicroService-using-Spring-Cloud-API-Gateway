package com.product.main.service;

import java.util.List;

import com.product.main.model.Product;

public interface ProductService {

	List<Product> getAllProducts();

	void saveProduct(Product product);

	List<Product> fetchByProductId(int id);

	/* Product updateProductId(Product product, int id); */

	
}

package com.order.main.service;

import java.util.List;

import com.order.main.model.Order;
import com.order.main.model.Product;

public interface OrderService {

	void saveOrder(Order order);

	List<Order> getAllOrders();

	List<Order> getById(int id);
	
	Product fetchByProductId(String Id);


}

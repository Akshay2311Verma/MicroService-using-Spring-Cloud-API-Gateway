package com.order.main.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Order_Table")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "O_Id")
	private int id;
	
	private String name;
	
	private String address;
	
	private String orderStatus;
	
	private int product_id;
	
	private int quantity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Order(int id, String name, String address, String orderStatus, Date orderDate, int product_id,
			int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.orderStatus = orderStatus;
		this.product_id = product_id;
		this.quantity = quantity;
	}

	public Order() {
		super();
	}

	public String toString() {
		return "Order [id=" + id + ", name=" + name + ", address=" + address + ", orderStatus=" + orderStatus
				+ ", product_id=" + product_id + ", quantity=" + quantity + "]";
	}
	
	
	
}

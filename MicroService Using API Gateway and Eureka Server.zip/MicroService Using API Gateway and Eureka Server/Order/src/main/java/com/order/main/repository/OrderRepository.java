package com.order.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.main.model.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	List<Order> findById(int id);
}

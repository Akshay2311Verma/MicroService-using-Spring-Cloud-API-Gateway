package com.order.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.main.model.Order;
import com.order.main.model.Product;
import com.order.main.repository.OrderRepository;
import com.order.main.repository.ProductRepository;


@Service
public class OrderServiceImpl implements OrderService {

	
	@Autowired
	OrderRepository repo;
	
	@Autowired
	ProductRepository prodRepo;
	
	public void saveOrder(Order order) {
		repo.save(order);
	}
	
	public List<Order> getAllOrders() {
		
		return repo.findAll();
	}

	public List<Order> getById(int id) {
		return repo.findById(id);
	}
	
	public Product fetchByProductId(String id) {
		
		Optional<Product> prod = prodRepo.findById(Integer.valueOf(id));
		
		return  prod.get();
	}

}

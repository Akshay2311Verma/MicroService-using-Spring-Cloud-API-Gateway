package com.invoice.main.service;

import org.springframework.stereotype.Service;

import com.invoice.main.model.Invoice;
import com.invoice.main.model.Order;
import com.invoice.main.model.Product;


@Service
public interface InvoiceService {

	Order fetchByOrderId(String Id);

	Product fetchByProductId(String Id);

	void saveBill(Invoice invoice);

}

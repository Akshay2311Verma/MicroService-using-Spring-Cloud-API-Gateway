package com.invoice.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.invoice.main.model.Invoice;
import com.invoice.main.model.Order;
import com.invoice.main.model.Product;
import com.invoice.main.service.InvoiceService;


@RestController
@RequestMapping("/invoice")
public class InvoiceController {

	int amount, quantity, price;
	@Autowired
	InvoiceService invoiceService;
	
	@Autowired
	Order order;
	
	public Order oid;
	public Product prodId;
	
	@PostMapping("/bill")
	public ResponseEntity<String> bill(@Validated @RequestBody Invoice invoice)
	{
		 String message = ""; 
		
		try {
			 oid = invoiceService.fetchByOrderId(String.valueOf(invoice.getOrder_Id()));
			Product prodId = invoiceService.fetchByProductId(String.valueOf(oid.getProduct_id()));
			if(oid.getOrderStatus().contains("Paid"))
			{
				quantity = oid.getQuantity();
				price = prodId.getProduct_Price();
				amount = price * quantity;
				
				
				  message = "Total Ammount Of Order Id" +" "+oid.getId()+"with Bill Id"+" "+invoice.getId()+"is = "+amount;
				/* return new ResponseEntity<String>(message, HttpStatus.OK); */
				 
			}
			else if(oid.getOrderStatus().contains("Cancelled"))
			{
				message = "Order Cancelled";
				return new ResponseEntity<String>(message, HttpStatus.OK); 
			}
			
		}catch (Exception e) {
			message = "No Content Found";
			return new ResponseEntity<String>(message, HttpStatus.NO_CONTENT);
		}
		invoice.setBill(amount);
		invoice.setPaymentStatus(oid.getOrderStatus());
		invoiceService.saveBill(invoice);
		/* message = "Bill Saved with Bill ID="+invoice.getId(); */
		//message = "Total Ammount Of Order Id" +" "+oid.getId()+"with Bill Id"+" "+invoice.getId()+"is = "+amount;
		 message = "Total Ammount Of Order Id" +" "+oid.getId()+"with Bill Id"+" "+invoice.getId()+"is = "+amount;
		return new ResponseEntity<String>(message,HttpStatus.OK);
	}
}

package com.invoice.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Invoice_Table")
public class Invoice {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private int order_Id;
	
	private String paymentStatus;
	
	 private int bill; 

	//Getter & Setters
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrder_Id() {
		return order_Id;
	}

	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	
	  public int getBill() { return bill; }
	  
	  public void setBill(int bill) { this.bill = bill; }
	 

	public Invoice(int id, int order_Id, String paymentStatus, int bill) {
		super();
		this.id = id;
		this.order_Id = order_Id;
		this.paymentStatus = paymentStatus;
		 this.bill = bill; 
	}

	public Invoice() {
		super();
	}

	public String toString() {
		return "Invoice [id=" + id + ", order_Id=" + order_Id + ", paymentStatus=" + paymentStatus + ", bill=" + bill
				+ "]";
	}

	

	
	
	
}

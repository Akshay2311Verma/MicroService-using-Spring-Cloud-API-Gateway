package com.invoice.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.invoice.main.model.Invoice;
import com.invoice.main.model.Order;
import com.invoice.main.model.Product;
import com.invoice.main.repository.InvoiceRepository;
import com.invoice.main.repository.OrderRepository;
import com.invoice.main.repository.ProductRepository;

@Service
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	InvoiceRepository repo;
	
	@Autowired
	OrderRepository orderRepo;
	
	@Autowired
	ProductRepository prodRepo;
	
	
	public Order fetchByOrderId(String id) {
		Optional<Order> oid = orderRepo.findById(Integer.valueOf(id));
		return oid.get();
	}

	public Product fetchByProductId(String id) {
		Optional<Product> prod = prodRepo.findById(Integer.valueOf(id));
		return prod.get();
	}

	public void saveBill(Invoice invoice) {
	
		repo.save(invoice);
	}

}

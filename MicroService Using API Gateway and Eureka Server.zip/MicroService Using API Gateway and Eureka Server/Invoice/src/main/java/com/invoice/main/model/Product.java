package com.invoice.main.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "Product_Table")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	private String product_Name;
	
	private String product_Category;
	
	private int product_Price;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProduct_Name() {
		return product_Name;
	}

	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}

	public int getProduct_Price() {
		return product_Price;
	}

	public void setProduct_Price(int product_Price) {
		this.product_Price = product_Price;
	}

	public String getProduct_Category() {
		return product_Category;
	}

	public void setProduct_Category(String product_Category) {
		this.product_Category = product_Category;
	}

	public Product(int id, String product_Name, String product_Category, int product_Price) {
		super();
		this.id = id;
		this.product_Name = product_Name;
		this.product_Category = product_Category;
		this.product_Price = product_Price;
	}

	public Product() {
		super();
	}

	public String toString() {
		return "Product [id=" + id + ", product_Name=" + product_Name + ", product_Category=" + product_Category
				+ ", product_Price=" + product_Price + "]";
	}

	
}
